#  🌑Pedra, 📄Papel e ✂️Tesoura!

## Apresentação📄
Utilizando conceitos basicos da programação como:

* Lógica Basica
* Váriaveis
* Constantes
* Funções
* Estruturas condicionais
* DOM

## Tecnologias💻
* Html
* Css
* Js

### **Feito para estudo e diversão!!!**
