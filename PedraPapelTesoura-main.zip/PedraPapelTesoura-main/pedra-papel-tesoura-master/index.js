// Importando elementos do HTML

// Itens do jogo
// Sendo 0 = Pedra, 1 = Papel e 2 = Tesoura

// Função para alterar o score

// Adicionando eventos de click
